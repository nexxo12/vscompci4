<?php

namespace App\Models;

use CodeIgniter\Model;

class Pembelian extends Model
{
    protected $table      = 'pembelian_barang';
    protected $allowedFields = ['ID_BELI', 'ID_SUPP', 'ID_BARANG', 'JUMLAH', 'NamaSUPP', 'SATUAN', 'HARGA_BELI', 'TGL_GARANSI', 'TGL_BELI'];


    public function AutoNumID()
    {
        $id = $this->selectCount('ID_BELI')->findAll();
        foreach ($id as $key) {
            $id_n = $key['ID_BELI'] + 1;
        }
        return $id_n;
    }
}
