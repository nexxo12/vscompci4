<footer class="footer">
    © <?= date('Y'); ?> - VSKomputer.
</footer>