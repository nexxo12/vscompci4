<?php

namespace App\Controllers;

use App\Models\Pembelian;
use App\Models\Masterbarang;
use App\Models\Supplier;
use App\Models\InvPenjualan;
use App\Models\Customer;
use App\Models\Listpenjualan;
use App\Models\PenjualanModel;
use \Hermawan\DataTables\DataTable;

class Transaksi extends BaseController
{

	protected $pembelian;
	protected $masterbarang;
	protected $supplier;
	protected $inv_pj;
	protected $customer;
	protected $list_pj;
	protected $penjualanID;
	public function __construct()
	{
		$this->pembelian = new Pembelian();
		$this->masterbarang = new Masterbarang();
		$this->supplier = new Supplier();
		$this->inv_pj = new InvPenjualan();
		$this->customer = new Customer();
		$this->list_pj = new Listpenjualan();
		$this->penjualanID = new PenjualanModel();
	}

	// CONTROLLER PAGE PEMBELIAN===================================
	public function pembelian()
	{
		$data = [
			'tittle' => 'Pembelian - VSKomputer',
			'autonum' => $this->pembelian->AutoNumID(),
			'showbarang' => $this->masterbarang->ShowBarang(),
			'supplier' => $this->supplier->ShowSupplier(),
			'showpembelian' => $this->pembelian->showpembelian()
		];
		return view('/transaksi/pembelian', $data);
	}
	public function deletePembelian($id)
	{
		$this->pembelian->delete($id);
		return redirect()->to('/transaksi/pembelian');
		// $id = $this->request->getVar('id');
		// $hapus = $this->pembelian->deletebuy($id);
		// if ($hapus) {
		// 	return redirect()->to('transaksi/pembelian');
		// }
	}
	public function savePembelian()
	{
		$this->pembelian->insert([
			'ID_BELI' => $this->request->getVar('id_pembelian'),
			'ID_SUPP' => $this->request->getVar('id-supp'),
			'ID_BARANG' => $this->request->getVar('idbarang'),
			'JUMLAH' => $this->request->getVar('jumlah'),
			'NamaSUPP' => $this->request->getVar('nama_supp'),
			'SATUAN' => $this->request->getVar('satuan'),
			'HARGA_BELI' => $this->request->getVar('hargabeli'),
			'TGL_GARANSI' => $this->request->getVar('garansi_buy'),
			'TGL_BELI' => $this->request->getVar('tanggal_input'),
		]);
		session()->setFlashData('pesan', 'Data Pembelian Berhasil Ditambahkan');
		return redirect()->to('/transaksi/pembelian');
	}
	//  END CONTROLLER PEMBELIAN======================================

	// CONTROLLER PAGE PENJUALAN===================================
	public function penjualan()
	{
		$data = [
			'tittle' => 'Penjualan - VSKomputer',
			'autonumPJ' => $this->inv_pj->invoicepj(),
			'showbarang' => $this->masterbarang->ShowBarang(),
			'showcustomer' => $this->customer->showcustomer()
		];
		return view('/transaksi/penjualan', $data);
	}

	public function showstok()
	{
		if ($this->request->isAJAX()) {
			$result = $this->masterbarang->showCariBarang();
			return json_encode($result);
			// $db = \Config\Database::connect();
			// $builder = $db->table('master_barang')->select('ID_BARANG, NAMA_BARANG, STOK, HARGA_JUAL');
			// return DataTable::of($builder)->toJson();
		}
	}

	public function addbarang()
	{
		$idbarang = $this->request->getVar('id');
		$result = $this->masterbarang->showbarangbyid($idbarang);
		return json_encode($result);
	}

	public function showlistbarang()
	{
		if ($this->request->isAJAX()) {
			$result = $this->list_pj->showlistpenjualan();
			return json_encode($result);
			// $db = \Config\Database::connect();
			// $builder = $db->table('list_penjualan')->select('ID_BARANG, HARGA_JL, JUMLAH_BELI, TOTAL_HARGA');
			// return DataTable::of($builder)->addNumbering()->toJson();
		}
	}
	public function refreshidpj()
	{
		if ($this->request->isAJAX()) {
			$result = $this->penjualanID->AutonumIDPJ();
			return json_encode($result);
		}
	}

	public function TotalHarga()
	{
		if ($this->request->isAJAX()) {
			$id = $this->request->getVar('id');
			$result = $this->list_pj->TotalPJ($id);
			return json_encode($result);
		}
	}

	public function addcart()
	{
		if ($this->request->isAJAX()) {
			$this->list_pj->insert([
				'ID_PENJUALAN' => $this->request->getVar('idpenjualan'),
				'INV_PENJUALAN' => $this->request->getVar('invoice'),
				'ID_BARANG' => $this->request->getVar('idbarang'),
				'JUMLAH_BELI' => $this->request->getVar('qty'),
				'HARGA_JL' => $this->request->getVar('harga'),
				'TOTAL_HARGA' => $this->request->getVar('harga') * $this->request->getVar('qty')

			]);
			// return redirect()->to('index');
		}
	}

	public function deletecart()
	{
		$id = $this->request->getVar('id');
		$result = $this->list_pj->deletelist($id);
		return json_encode($result);
	}
	//  END CONTROLLER PENJUALAN======================================
	public function serviceReturn()
	{
		$data = [
			'tittle' => 'Service & Return - VSKomputer'
		];
		return view('/transaksi/return', $data);
	}

	public function garansi()
	{
		$data = [
			'tittle' => 'Garansi - VSKomputer'
		];
		return view('/transaksi/garansi', $data);
	}
}
